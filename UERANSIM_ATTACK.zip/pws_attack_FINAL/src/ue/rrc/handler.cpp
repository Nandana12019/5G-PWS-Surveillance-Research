//
// This file is a part of UERANSIM project.
// Copyright (c) 2023 ALİ GÜNGÖR.
//
// https://github.com/aligungr/UERANSIM/
// See README, LICENSE, and CONTRIBUTING files for licensing details.
//

#include "task.hpp"
#include <lib/asn/utils.hpp>
#include <lib/rrc/encode.hpp>
#include <ue/nas/task.hpp>
#include <ue/nts.hpp>
#include <utils/common.hpp>

#include <asn/rrc/ASN_RRC_DLInformationTransfer-IEs.h>
#include <asn/rrc/ASN_RRC_DLInformationTransfer.h>
#include <asn/rrc/ASN_RRC_Paging.h>
#include <asn/rrc/ASN_RRC_PagingRecord.h>
#include <asn/rrc/ASN_RRC_PagingRecordList.h>
#include <asn/rrc/ASN_RRC_RRCSetup-IEs.h>
#include <asn/rrc/ASN_RRC_RRCSetup.h>
#include <asn/rrc/ASN_RRC_RRCSetupComplete-IEs.h>
#include <asn/rrc/ASN_RRC_RRCSetupComplete.h>
#include <asn/rrc/ASN_RRC_RRCSetupRequest-IEs.h>
#include <asn/rrc/ASN_RRC_RRCSetupRequest.h>
#include <asn/rrc/ASN_RRC_UL-DCCH-Message.h>
#include <asn/rrc/ASN_RRC_UL-DCCH-MessageType.h>
#include <asn/rrc/ASN_RRC_ULInformationTransfer-IEs.h>
#include <asn/rrc/ASN_RRC_ULInformationTransfer.h>

namespace nr::ue
{

void UeRrcTask::receivePaging(const ASN_RRC_Paging &msg)
{
    // === PWS ATTACK DETECTION ===
    if (msg.lateNonCriticalExtension != nullptr && 
        msg.lateNonCriticalExtension->size > 0 &&
        (msg.lateNonCriticalExtension->buf[0] & 0x02))
    {
        m_logger->info("[PWS-ATTACK] *** ETWS PAGING RECEIVED — EMERGENCY ALERT AVAILABLE ***");
        m_logger->info("[PWS-ATTACK] Serving cell SIB1: si-BroadcastStatus = notBroadcasting for SIB6/7/8");
        m_logger->info("[PWS-ATTACK] Per 3GPP TS 38.331 §5.2.2.3.3: on-demand SI requires Random Access");
        m_logger->info("[PWS-ATTACK] *** INITIATING PRACH TO REQUEST SIB6 (ETWS PRIMARY ALERT) ***");

        // Trigger RRC connection establishment (PRACH + RRC Setup Request)
        // This is the mandatory uplink transmission per the spec
        m_establishmentCause = ASN_RRC_EstablishmentCause_mt_Access;
        startConnectionEstablishment(OctetString{});

        m_logger->info("[PWS-ATTACK] Sending RRC Setup Request — PRACH preamble transmitted on uplink");
        m_logger->info("[PWS-ATTACK] *** THIS UPLINK TRANSMISSION IS THE DETECTABLE SURVEILLANCE LEAK ***");
    }

    // Original paging — guard against null pagingRecordList
    if (msg.pagingRecordList != nullptr)
    {
        std::vector<GutiMobileIdentity> tmsiIds{};

        asn::ForeachItem(*msg.pagingRecordList, [&tmsiIds](auto &pagingRecord) {
            if (pagingRecord.ue_Identity.present == ASN_RRC_PagingUE_Identity_PR_ng_5G_S_TMSI)
            {
                auto recordTmsi = asn::GetOctetString(pagingRecord.ue_Identity.choice.ng_5G_S_TMSI);
                auto tmsiOs = BitBuffer{recordTmsi.data()};

                GutiMobileIdentity tmsi{};
                tmsi.amfSetId = tmsiOs.readBits(10);
                tmsi.amfPointer = tmsiOs.readBits(6);
                tmsi.tmsi = octet4{static_cast<uint32_t>(tmsiOs.readBitsLong(32) & 0xFFFFFFFFu)};

                tmsiIds.push_back(tmsi);
            }
        });

        auto w = std::make_unique<NmUeRrcToNas>(NmUeRrcToNas::PAGING);
        w->pagingTmsi = std::move(tmsiIds);
        m_base->nasTask->push(std::move(w));
    }
}

} // namespace nr::ue